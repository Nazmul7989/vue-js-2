<!--<template>-->
<!--  <form class="mt-5">-->
<!--    <div class="row">-->
<!--      <div class="col-md-3">-->
<!--        <div class="form-group">-->
<!--          <input type="text"  class="form-control" placeholder="Name">-->
<!--        </div>-->
<!--      </div>-->
<!--      <div class="col-md-3">-->
<!--        <div class="form-group">-->
<!--          <input type="email" class="form-control" placeholder="Email">-->
<!--        </div>-->
<!--      </div>-->
<!--      <div class="col-md-3">-->
<!--        <div class="form-group">-->
<!--          <input type="text"  class="form-control" placeholder="Phone No">-->
<!--        </div>-->
<!--      </div>-->
<!--      <div class="col-md-3">-->
<!--        <div class="form-group">-->
<!--          <input type="submit" class="btn btn-primary" value="Send">-->
<!--        </div>-->
<!--      </div>-->
<!--    </div>-->
<!--  </form>-->
<!--</template>-->


<!--<script>-->
<!--export default {-->
<!--  data(){-->
<!--    return{-->

<!--    }-->
<!--  },-->
<!--  activated() {-->
<!--    console.log('activated')-->
<!--  },-->
<!--  deactivated() {-->
<!--    console.log('deactivated')-->
<!--  }-->
<!--}-->
<!--</script>-->