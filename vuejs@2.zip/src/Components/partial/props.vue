<template>
  <div>
    <p>Name list:</p>
   <ul>
     <li v-for="name in names" :key="name">
       {{ name }}
     </li>
   </ul>
    <p>{{ surname }}</p>
    <button @click="updateName">Change name</button>
  </div>
</template>

<script>
  export default {
    props: {
     names :{
       type: Array,
       required: true
     },
      surname:{
       type: String
      }
    },
    methods: {
      updateName(){
        this.$emit('updateSurname','Rakib')
      }
    }
  }
</script>