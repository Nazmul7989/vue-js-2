<!--<template>-->
<!--  <div>-->
<!--    <slot name="listItem"></slot>-->
<!--    <p>This is a slot example.</p>-->
<!--    <slot name="para"></slot>-->
<!--  </div>-->
<!--</template>-->

<!--<style scoped>-->

<!--div{-->
<!--  color: darkviolet;-->
<!--}-->

<!--</style>-->