<!--<template>-->
<!--  <div>-->
<!--    Footer-->
<!--  </div>-->
<!--</template>-->

<!--<style scoped>-->
<!--div{-->
<!--  color: green;-->
<!--}-->
<!--</style>-->