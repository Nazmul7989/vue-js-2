// export const nameMixin = {
//     data(){
//         return{
//             txt: 'Hello mixin',
//             names: ['Nazmul','Sonia','Roni','Kamal']
//         }
//     }
// }
