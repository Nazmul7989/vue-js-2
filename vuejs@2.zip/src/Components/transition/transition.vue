
<!--<template>-->
<!--  <div>-->
<!--    <transition name="showItem">-->
<!--      <p class="bg-success p-2 text-white" v-if="display"> This is a demo transition property </p>-->
<!--    </transition>-->
<!--    <button @click="display =! display ">Toggle</button>-->
<!--  </div>-->
<!--</template>-->

<!--<script>-->
<!--export default {-->
<!--  data(){-->
<!--    return{-->
<!--      display: false,-->
<!--    }-->
<!--  }-->
<!--}-->
<!--</script>-->



<!--<style>-->
<!--.showItem-enter{-->
<!--  opacity: 0;-->
<!--}-->
<!--.showItem-enter-active{-->
<!--  transition: opacity 3s;-->
<!--}-->
<!--.showItem-leave{-->

<!--}-->
<!--.showItem-leave-active{-->
<!--  opacity: 0;-->
<!--  transition: opacity 3s;-->
<!--}-->
<!--</style>-->